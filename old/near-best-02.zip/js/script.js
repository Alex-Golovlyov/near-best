$(document).ready(function () {

    $('.source-pics').slick({
      dots: true,
      arrows: false,
      fade: true,
      cssEase: 'linear'
    });
    $('.partners-block').slick({
      dots: true,
      arrows: false
    });

    $(".form-phone").mask("+7 (999) 999-9999");

    $('.popup-btn').on("click", function(e){
        e.preventDefault();
        let btnName = this.id;
        let formName = '';
        switch (btnName) {
          case 'btn-2': {
            formName = 'Главный экран (узнать подробнее)';
            break;
          }
          case 'consult-btn': {
            formName = 'Заявка на консультацию';
            break;
          }
          case 'getspec-btn': {
            formName = 'Скачать спецификации';
            break;
          }
          default: formName = 'Лид-форма';
        }
        $(".form-theme").val(formName);
        $(".overlay").fadeIn();
        $(".lead-form").delay(100).fadeIn();

    });

    $(".btn-close, .overlay").click(function (ef) {
        ef.preventDefault();
      $(".overlay, .lead-form").fadeOut();
    });

    $(".form-element").submit(function () {
        var formID = $(this).attr('id');
        var formNm = $('#' + formID);
        var message = $(formNm).find(".form-message");
        var formTitle = $(formNm).find(".form-title");
        $.ajax({
            type: "POST",
            url: 'to-telegram.php',
            data: formNm.serialize(),
            success: function (data) {
              message.html(data);
              formTitle.css("display","none");
              setTimeout(function(){
                formTitle.css("display","block");
                message.html('');
                $('input').not(':input[type=submit], :input[type=hidden]').val('');
              }, 3000);
            },
            error: function (jqXHR, text, error) {
                message.html(error);
                formTitle.css("display","none");
                setTimeout(function(){
                  formTitle.css("display","block");
                  message.html('');
                  $('input').not(':input[type=submit], :input[type=hidden]').val('');
                }, 3000);
            }
        });
        return false;
    });

});