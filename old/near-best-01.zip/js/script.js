$(document).ready(function () {

    $('.source-pics').slick({
      dots: true,
      arrows: false,
      fade: true,
      cssEase: 'linear'
    });
    $('.partners-block').slick({
      dots: true,
      arrows: false
    });

    $(".form-phone").mask("+7 (999) 999-9999");

    $('.popup-btn').on("click", function(e){
        e.preventDefault();
        let btnName = this.id;
        let formName = '';
        switch (btnName) {
          case 'btn-2': {
            formName = 'Главный экран (узнать подробнее)';
            break;
          }
          case 'consult-btn': {
            formName = 'Заявка на консультацию';
            break;
          }
          case 'getspec-btn': {
            formName = 'Скачать спецификации';
            break;
          }
          default: formName = 'Лид-форма';
        }
        $(".form-theme").val(formName);
        $(".overlay").fadeIn();
        $(".lead-form").delay(100).fadeIn();

    });

    $(".btn-close, .overlay").click(function (ef) {
        ef.preventDefault();
      $(".overlay, .lead-form").fadeOut();
    });

    $(".form-element").submit(function () {
        var formID = $(this).attr('id');
        var formNm = $('#' + formID);
        var message = $(formNm).find(".form-message");
        var formTitle = $(formNm).find(".form-title");
        $.ajax({
            type: "POST",
            url: 'to-telegram.php',
            data: formNm.serialize(),
            success: function (data) {
              // Вывод сообщения об успешной отправке
              message.html(data);
              formTitle.css("display","none");
              setTimeout(function(){
                formTitle.css("display","block");
                message.html('');
                $('input').not(':input[type=submit], :input[type=hidden]').val('');
              }, 3000);
            },
            error: function (jqXHR, text, error) {
                // Вывод сообщения об ошибке отправки
                message.html(error);
                formTitle.css("display","none");
                setTimeout(function(){
                  formTitle.css("display","block");
                  message.html('');
                  $('input').not(':input[type=submit], :input[type=hidden]').val('');
                }, 3000);
            }
        });
        return false;
    });

    var view = [
      {btnName: 'view_btn1', view_pic: 'azs-pic-01' },
      {btnName: 'view_btn2',	view_pic: 'azs-pic-02' },
      {btnName: 'view_btn3',	view_pic: 'azs-pic-03' }
    ];
  
    view.forEach(function(item) {
      $("#" + item.btnName).click(function(event) {
        $(".azs-pic img").fadeOut(200);
        $("#"+item.view_pic).fadeIn(200);
        $(".btn-block div").removeClass('active-view');
        $(this).addClass('active-view');
      });
    });
    $("#view_btn1").click();
});